A simple projects which is based on games review where user can select games, review information about them, add to it (by commenting about the game)
or adding the game and streamer to the server.

Everything should be set up by using npm install

Citations/Source:
    Source for visually hidding elements: https://a11yproject.com/posts/how-to-hide-content/
    Inspiration for handling event change efficiently:  https://www.pluralsight.com/guides/handling-multiple-inputs-with-single-onchange-handler-react 

Thanks 
Parteet Singh

